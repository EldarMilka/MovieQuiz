//
//  Models.swift
//  MovieQuiz
//
//  Created by Эльдар on 01.04.2025.
//

import Foundation
