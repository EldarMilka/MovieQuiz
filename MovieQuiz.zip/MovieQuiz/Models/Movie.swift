//
//  Movie.swift
//  MovieQuiz
//
//  Created by Эльдар on 08.04.2025.
//

import Foundation

